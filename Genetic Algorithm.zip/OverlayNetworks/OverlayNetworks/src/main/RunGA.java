package main;


import ga.GeneticAlgorithm;
import ga.Population;
import ga.Chromosome;
import java.util.Arrays;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import utils.FileHelper;

public class RunGA {

	public static void main(String args[]) {
		Vector network = new Vector();
		
		// read file
		FileHelper filehelper = new FileHelper();
		String fileName = "D:\\eclipse projects\\OverlayNetworks\\OverlayNetworks\\network.txt";
		try {
			network = filehelper.readFile(fileName);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		// to do
		// call and run genetic algorithm
		// e.g. GeneticAlgorithm ga = new GeneticAlgorithm(network, populationSize, crossoverProb, mutationProb);
		// ...
		Population population = new Population(100,network).initializePopulation();
		GeneticAlgorithm geneticAlgorithm = new GeneticAlgorithm();
		Vector bestFitness = new Vector();
		Vector averageFitness = new Vector();
		System.out.println("------------------------------------------------------");
		System.out.println("Generation # 0 " + " | Fittest chromosome fitness: "+ population.getChromosomes()[0].getFitness());
		bestFitness.add(population.getChromosomes()[0].getFitness());
		averageFitness.add(getAverageFitness(population));
		int generationNumber = 0; 
			while (generationNumber< 1000) { 
			generationNumber++;
			System.out.println("\n-------------------------------------------------------");
			population = geneticAlgorithm.evolve(population);
			population.sortChromosomesByFitness();
			System.out.println("Generation # "+generationNumber+" | Fittest chromosome fitness: "+ population.getChromosomes()[0].getFitness());
			bestFitness.add(population.getChromosomes()[0].getFitness());
			averageFitness.add(getAverageFitness(population));
			printPopulation(population, "Best Fitness: " + population.getChromosomes()[0].toString());
			writeUsingFileWriter(bestFitness,averageFitness);
		}
			
	}
	public static void printPopulation(Population population, String heading) {
		System.out.println(heading);
		System.out.print("-------------------------------------------------------\n");
		for (int i = 0; i< population.getChromosomes().length; i++ ) {
			System.out.println("Chromosome # "+ i + " : "+Arrays.toString(population.getChromosomes()[i].getGenes())+ " | Fitness: "+ population.getChromosomes()[i].getFitness()
					);
		}
	}
	
	public static double getAverageFitness(Population population) {
		double totalFitness = 0;
		double average=0;
		for(int i =0; i< population.getChromosomes().length;i++) {
			totalFitness+=population.getChromosomes()[i].getFitness();
		}
		average = totalFitness/population.getChromosomes().length;
		return average;
	}
	private static void writeUsingFileWriter(Vector bestFitness,Vector averageFitness) {
        File file = new File("GAresult.txt");
        FileWriter fr = null;
        try {
            fr = new FileWriter(file);
            for(int i =0; i< bestFitness.size();i++) {
            	fr.write(bestFitness.get(i).toString());
            	fr.write(", "+averageFitness.get(i).toString()+"\n");
            }
            
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            //close resources
            try {
                fr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
	
}
