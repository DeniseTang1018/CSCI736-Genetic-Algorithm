package ga;

import java.util.Arrays;
import java.util.Random;
import java.util.Vector;
import utils.*;

public class Chromosome {

	private boolean isFitnessChanged = true;
	private int[] genes;
	private double fitness = 0;
	private static Vector network;
	public Chromosome(int length, Vector network) {
		genes = new int [length];
		this.network = network;
	}
	public Chromosome(int length) {
		genes = new int [length];
	}
	public Chromosome initializeChromosome() {
		Random rand = new Random();
		for (int i =0; i< genes.length; i++) {
			if(rand.nextDouble()>=0.5) {
				genes[i]=1;
			}
			else {
				genes[i]=0;
			}
		}
		return this;
	}
	public int[] getGenes() {
		isFitnessChanged =true;
		return genes;
	}
	public double getFitness() {
		if (isFitnessChanged) {
			fitness = recalculateFitness();
			isFitnessChanged = false;
		}
		return fitness;
	}
	public double recalculateFitness() {
		double chromosomeFitness = 0;
		Fitness fitness = new Fitness();
		chromosomeFitness =fitness.calculateFitnessOfOverlayNetwork(getActivatedNetwork());
		return chromosomeFitness;
	}
	private Vector<Link> getActivatedNetwork(){
		Vector temp = new Vector(network.size());
		for(int i =0; i < network.size();i++) {
			temp.add(network.get(i));
		}
		Vector<Link> activatedNetwork = temp;
		for(int i =0; i < activatedNetwork.size();i++) {
			if(genes[i] == 1) {
				activatedNetwork.get(i).setActive(1);
			}else {
				activatedNetwork.get(i).setActive(0);
			}
		}
		return activatedNetwork;
	}
	public String toString() {
		return Arrays.toString(this.genes);
	}
	
}
