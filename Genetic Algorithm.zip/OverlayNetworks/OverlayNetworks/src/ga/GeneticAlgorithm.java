package ga;

import utils.*;

import java.util.*;

public class GeneticAlgorithm {

	// to be implemented along with any other classes you might create such as
	// crossover, mutation, selection, etc.

	public static final int POPULATION_SIZE = 100;
	private static final double MUTATION_RATE = 0.001;
	public static final int NUMB_OF_ELITE_CHROMOSOMES =1; 
	public static final double CROSSOVER_RATE =0.70;
	public static final int TOURNAMENT_SELECTION_SIZE = 2;
	

	private Population crossoverPopulation(Population population) { 
		Population crossoverPopulation = new Population(population.getChromosomes().length);
		for(int i =0; i<NUMB_OF_ELITE_CHROMOSOMES;i++) {
		crossoverPopulation.getChromosomes()[i] = population.getChromosomes()[i];
		}
		for(int i = NUMB_OF_ELITE_CHROMOSOMES;i<population.getChromosomes().length;i++) {
			Population tournamentPopulation = selectTournamentPopulation(population);
			Chromosome chromosome1 = tournamentPopulation.getChromosomes()[0];
			Chromosome chromosome2 = tournamentPopulation.getChromosomes()[1];
			Population temp = crossoverChromosome(chromosome1,chromosome2);
			crossoverPopulation.getChromosomes()[i] =temp.getChromosomes()[0];
			if(i<population.getChromosomes().length-1) {
			crossoverPopulation.getChromosomes()[++i] = temp.getChromosomes()[1];
			}
		}
		return crossoverPopulation;
	}
	private Population mutatePopulation(Population population) {
		Population mutatePopulation = new Population(population.getChromosomes().length);
		for(int i =0; i<NUMB_OF_ELITE_CHROMOSOMES;i++) {
			mutatePopulation.getChromosomes()[i] = population.getChromosomes()[i];
			}
		for(int i = NUMB_OF_ELITE_CHROMOSOMES; i< population.getChromosomes().length;i++) {
			mutatePopulation.getChromosomes()[i] = mutateChromosome(population.getChromosomes()[i]);
		}
		return mutatePopulation;
	}
	public Population evolve(Population population) {
		return mutatePopulation(crossoverPopulation(population));
	}

	private Population crossoverChromosome(Chromosome chromosome1, Chromosome chromosome2) {
		Population crossoverChromosome = new Population (TOURNAMENT_SELECTION_SIZE);
		crossoverChromosome.getChromosomes()[0] = new Chromosome(300);
		crossoverChromosome.getChromosomes()[1] = new Chromosome(300);
		Random rand = new Random();
		if(rand.nextDouble()<=CROSSOVER_RATE) {
			int crossoverPointS = rand.nextInt(300);
			int crossoverPointE = rand.nextInt(300-crossoverPointS)+crossoverPointS;
			for(int i=0; i<chromosome1.getGenes().length;i++) {
				if(i<crossoverPointS || i > crossoverPointE) {
					crossoverChromosome.getChromosomes()[0].getGenes()[i] = chromosome1.getGenes()[i];
					crossoverChromosome.getChromosomes()[1].getGenes()[i] = chromosome2.getGenes()[i];
				}else if(i >= crossoverPointS && i <= crossoverPointE) {
					crossoverChromosome.getChromosomes()[1].getGenes()[i] = chromosome1.getGenes()[i];
					crossoverChromosome.getChromosomes()[0].getGenes()[i] = chromosome2.getGenes()[i];
				}
				
			}
		}else {
			for(int i=0; i<chromosome1.getGenes().length;i++) {
				
					crossoverChromosome.getChromosomes()[0].getGenes()[i] = chromosome1.getGenes()[i];
					crossoverChromosome.getChromosomes()[1].getGenes()[i] = chromosome2.getGenes()[i];
			
			}
		}
		return crossoverChromosome;
	}
	private Chromosome mutateChromosome(Chromosome chromosome) {
		Chromosome mutateChromosome = new Chromosome(300);
		Random rand = new Random();
		for(int i =0; i<chromosome.getGenes().length;i++) {
			if(rand.nextDouble() <= MUTATION_RATE) {
			if(chromosome.getGenes()[i]==0) {
				mutateChromosome.getGenes()[i] = 1;
			}else {
				mutateChromosome.getGenes()[i] = 0;
			}
			}else {
				mutateChromosome.getGenes()[i] = chromosome.getGenes()[i];
			}
		
		}
		return mutateChromosome;
	}
	private Population selectTournamentPopulation (Population population) {
		Population tournamentPopulation = new Population (TOURNAMENT_SELECTION_SIZE);
		Random rand = new Random();
		for(int i =0; i<TOURNAMENT_SELECTION_SIZE;i++) {
			tournamentPopulation.getChromosomes()[i] = population.getChromosomes()[rand.nextInt(100)];
		}
		tournamentPopulation.sortChromosomesByFitness();
		return tournamentPopulation;
	}
}
